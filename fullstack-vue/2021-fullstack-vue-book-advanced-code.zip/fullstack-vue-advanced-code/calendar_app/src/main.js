import { createApp } from 'vue';
import App from './app-complete/App.vue';

createApp(App).mount('#app');
