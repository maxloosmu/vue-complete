- `npm install` to install package dependencies

- `npm run start` to run Node:Express server

- Navigate to `http://localhost:9000/api` to launch GraphQL Playground
