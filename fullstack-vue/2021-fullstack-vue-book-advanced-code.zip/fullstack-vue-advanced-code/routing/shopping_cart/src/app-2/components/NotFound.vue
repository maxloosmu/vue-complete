<template>
  <div class="has-text-centered">
    <h1 class="title">Sorry. Page Not Found :(</h1>
    <p>Use the navigation links above to navigate between the product and 
      cart screens.</p>
  </div>
</template>

<script>
export default {
  name: 'NotFound',
}
</script>

<style scoped>
</style>
