### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

# Fullstack Vue

## Composition API

1. Ensure you have `npm` installed.

2. Install the dependencies

```
npm install
```

3. Boot the app

```
npm run start
```

The Node and Webpack servers are now running - watch the console output for instructions. Your entire application is now available at [http://localhost:8080/](http://localhost:8080/)
