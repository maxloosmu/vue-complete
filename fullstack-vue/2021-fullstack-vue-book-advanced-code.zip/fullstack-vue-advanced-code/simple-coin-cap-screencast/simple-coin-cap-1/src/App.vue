<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style src="@/assets/styles/app.css">
</style>
