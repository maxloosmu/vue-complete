<template>
  <div id="not-found">
    <h2 class="ui center icon header">
      <i class="question circle icon"></i>
      Sorry! This page can't be found
    </h2>
	</div>
</template>

<script>
export default {
  name: 'NotFoundPage'
}
</script>

<style src="@/assets/styles/not-found-page.css">
</style>
