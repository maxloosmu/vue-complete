<template>
  <h1>The Server is Ready!!</h1>
</template>

<script>
export default {
  name: 'HomePage'
}
</script>

<style>

</style>
