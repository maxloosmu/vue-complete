describe('WeatherContainer.vue', () => {
  
});
