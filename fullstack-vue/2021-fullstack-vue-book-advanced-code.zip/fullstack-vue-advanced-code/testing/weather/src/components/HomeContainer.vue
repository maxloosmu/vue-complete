<template>
  <h1 class="subtitle is-size-3">Pick a city below to see the weather!</h1>
</template>

<script>
export default {
  name: 'HomeContainer',
}
</script>
