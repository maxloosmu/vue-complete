Vue.createApp({}).mount('#app')
